/*
 * cdaux_iface_v1.h
 *
 *  Created on: Oct 5, 2017
 *      Author: user
 */

#ifndef CDAUX_IFACE_V1_H_
#define CDAUX_IFACE_V1_H_


#include "cdaux.h"


#endif /* CDAUX_IFACE_V1_H_ */
