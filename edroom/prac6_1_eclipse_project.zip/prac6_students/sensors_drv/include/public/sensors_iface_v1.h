/*
 * sensor_iface_v1.h
 *
 *  Created on: May 15, 2016
 *      Author: user
 */

#ifndef SENSOR_IFACE_V1_H_
#define SENSOR_IFACE_V1_H_

#include <public/sensors.h>

#endif /* SENSOR_IFACE_V1_H_ */
